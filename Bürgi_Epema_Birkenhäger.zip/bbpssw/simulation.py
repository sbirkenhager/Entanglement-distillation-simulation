import subprocess as sub
import os
import numpy as np
from tqdm import tqdm

#This file should be in the protocol's folder

file_name = "app_bob.py"  # This is the script that saves the results, can either be app_bob or app_alice, but not both

N_rep = 200 # number of simulations per parameter set
p_range = list(np.linspace(0.5, 1,
                           11))  # Values of p for which the simulation is run, where 1-p is the probability for the intial state to depolarise
g_range = list(np.linspace(0.75, 1, 6))  # Values of the gate fidelity g for which the simulation is run




def network_fidelities(p, F_g):
    """
    Updates the fidelities in "network.yaml", to be able to run the simulation for the new values of g and p

    :parameter p: probability p of initial state to depolarise, meaning the initial fidelity is (1+3*p)/4
    :parameter g: the gate fidelity g
    """

    networkstring = \
"""nodes:
  - name: "the_hague"
    gate_fidelity: {0:0.4f}
    qubits:
      - id: 0
        t1: 0
        t2: 0
      - id: 1
        t1: 0
        t2: 0
  - name: "delft"
    gate_fidelity: {0:0.4f}
    qubits:
      - id: 0
        t1: 0
        t2: 0
      - id: 1
        t1: 0
        t2: 0

links:
  - name: ch1
    node_name1: "delft"
    node_name2: "the_hague"
    noise_type: Depolarise
    fidelity: {1:0.4f}""".format(F_g, p)

    f = open("network.yaml", "w")
    f.write(networkstring)
    f.close()

    return


def newvaluestoscript(p, F_g):
    """
    Updates the app file given by "file_name" to save the results to a data file with the name P{value p}_G{value g}.txt for the new values of p and g

    :parameter p: probability p of initial state to depolarise, meaning the initial fidelity is (1+3*p)/4
    :parameter g: the gate fidelity g
    """
    f = open(file_name, "r")
    text = f.read()
    f.close()

    text = text.split("\n")
    line = [i for i in range(len(text)) if "f = open" in text[i]][0]  # find the line that includes the output file name
    string_line = text[line]  # get the string from that line

    output_file_name = ("P{:0.4f}_G{:0.4f}".format(p, F_g)).replace(".",
                                                                    "-") + ".txt"  # the name of the file including the new values of p and g
    text[line] = string_line[:string_line.find("f = open")] + """f = open("data/{}", "a")""".format(
        output_file_name)  # update the filename in the script to the name of the current output file

    new_script = "\n".join(text)
    f = open(file_name, "w")  # save the new updated script to file_name (which is app_bob or app_alice)
    f.write(new_script)
    f.close()

    return


def results(file):
    """
    Returns the success probability and mean output fidelity of "file", including their corresponding standard deviations.

    Output is given as [probability, standard deviation of probability, output fidelity, standard deviation of output fidelity.
    """
    f = open("data/" + file_name, "r")
    text = f.read()
    f.close()

    data = []
    for line in text.split("\n")[:-1]:
        line = line.split(" ")
        success, fidelity = int(line[0]), float(line[1])
        data += [[success, fidelity]]

    # P_SUCC
    values = np.array([i[0] for i in data])
    probability = np.average(values)
    std_probability = np.std(values) / np.sqrt(len(values))

    # FIDELITY
    values = np.array([i[1] for i in data if i[0] == 1])
    fidelity = np.average(values)
    std_fidelity = np.std(values) / np.sqrt(len(values))

    return probability, std_probability, fidelity, std_fidelity




if "data" not in os.listdir():  # if in the folder of this protocol, a folder "data" does not already exist, make one
    os.mkdir("data")

for p in p_range:
    for F_g in g_range:

        N_simulations_done = 0  # initialize number of simulations done for these values of p and g

        # check whether simulations for these values have already been done and how many
        output_file_name = ("P{:0.4f}_G{:0.4f}".format(p, F_g)).replace(".", "-") + ".txt"
        if output_file_name in os.listdir("data"):  # find the number of simulations already done
            f = open("data/" + output_file_name, "r")
            txt = f.read()
            f.close()
            N_simulations_done = len(txt.split("\n")) - 1  # subtract 1 since there is an extra empty line

        # update p and g in the script "file_name"
        newvaluestoscript(p, F_g)

        # update the fidelities in the network.yaml file
        network_fidelities(p, F_g)

        # print current paramter vlaues
        print("p = {:0.4f} / g = {:0.4f}".format(p, F_g))

        # Peform remaining simulations
        for i in tqdm(range(N_rep - N_simulations_done)):
            sub.run(["netqasm", "simulate", "--formalism=dm"])

        # Calculate the results
        probability, std_probability, fidelity, std_fidelity = post_processing(output_file_name)
        print("initial fidelity:", (1 + 3 * p) / 4)
        print("p_succ:", probability, std_probability)
        print("fidelity:", fidelity, std_fidelity)

        print("\n")
